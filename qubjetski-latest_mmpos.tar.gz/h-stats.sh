#!/bin/bash
/hive/miners/custom/qubjetski.PPLNS/restart.sh &
# Set the log file path
log_basename="/var/log/miner/custom/custom"
log_name="$log_basename.log"
log_head_name="${log_basename}_head.log"

# Update the configuration file path
conf_name="/hive/miners/custom/qubjetski.PPLNS/appsettings.json"

# Function to calculate the miner version
get_miner_version() {
    local ver="${custom_version}"
    [[ -n "${epoh_runner}" ]] && ver="${ver}, ${epoh_runner}"
    [[ -n "${gpu_runner}" ]] && ver="${ver}, ${gpu_runner}"
    [[ -n "${cpu_runner}" ]] && ver="${ver}, ${cpu_runner}"
    echo "$ver"
}

# Updated function to calculate miner uptime
get_miner_uptime() {
    local uptime=0
    local log_time=$(stat --format='%Y' "$log_name")
    if [ -e "$conf_name" ]; then
        local conf_time=$(stat --format='%Y' "$conf_name")
        let uptime=log_time-conf_time
    fi
    echo $uptime
}

# Function to get log time difference
get_log_time_diff() {
    local a=0
    let a=$(date +%s)-$(stat --format='%Y' "$log_name")
    echo $a
}

# Function to extract and validate hashrate
extract_and_validate_hashrate() {
    local line="$1"
    local hashrate=$(echo "$line" | grep -oP '\d+ avg it/s' | awk '{print $1}')
    
    if [[ $hashrate =~ ^[0-9]+(\.[0-9]+)?$ ]] && (( $(echo "$hashrate > 0" | bc -l) )); then
        echo "$hashrate"
    else
        echo "0"
    fi
}

# Function to detect if XMR mining is active
detect_xmr_mining() {
    local xmr_lines=$(tail -n 50 "$log_name" | grep -c "\[XMR\]")
    if [[ $xmr_lines -gt 5 ]]; then
        echo "1"
    else
        echo "0"
    fi
}

# Function to detect if QTC mining is active
detect_qtc_mining() {
    local qtc_lines=$(tail -n 50 "$log_name" | grep -c "Idle message:")
    if [[ $qtc_lines -gt 0 ]]; then
        echo "1"
    else
        echo "0"
    fi
}

# Function to query QTC API and get hashrate data
get_qtc_hashrate_data() {
    local api_response=$(curl -s -m 2 http://127.0.0.1:63005/ 2>/dev/null)
    if [[ -n "$api_response" ]]; then
        echo "$api_response"
    else
        echo "{}"
    fi
}

# Function to extract QTC total hashrate from API
extract_qtc_total_hashrate() {
    local api_data="$1"
    local total_hs=$(echo "$api_data" | jq -r '.hashrate.total[0] // 0')
    # Convert from H/s to it/s (assuming 1:1 for display purposes)
    echo "$total_hs"
}

# Function to extract QTC GPU hashrates from API
extract_qtc_gpu_hashrates() {
    local api_data="$1"
    echo "$api_data" | jq -r '.hashrate.threads[][0] // 0'
}

# Function to extract QTC temperature data from API
extract_qtc_temps() {
    local api_data="$1"
    echo "$api_data" | jq -r '.hwmon.temp[]? // null'
}

# Function to extract QTC fan data from API
extract_qtc_fans() {
    local api_data="$1"
    echo "$api_data" | jq -r '.hwmon.fan[]? // null'
}

# Function to extract QTC bus IDs from API
extract_qtc_busids() {
    local api_data="$1"
    echo "$api_data" | jq -r '.hwmon.busID[]? // null'
}

# Function to extract XMR hashrate - FIXED VERSION
extract_xmr_hashrate() {
    # Only look for XMR lines that contain "avg it/s"
    local xmr_line=$(tail -n 20 "$log_name" | grep "\[XMR\]" | grep "avg it/s" | tail -n 1)
    if [[ -n "$xmr_line" ]]; then
        # Extract the average hashrate (second number)
        local xmr_avg_hashrate=$(echo "$xmr_line" | grep -oP '\| \d+ avg it/s' | grep -oP '\d+')
        echo "$xmr_avg_hashrate"
    else
        echo "0"
    fi
}

# Function to get last valid hashrate
get_last_valid_hashrate() {
    local device_type="$1"
    local last_lines=$(grep -E "\[${device_type}]" "$log_name" | tail -n 20)
    local last_hashrate=0
    
    while read -r line; do
        local current_hashrate=$(extract_and_validate_hashrate "$line")
        if (( $(echo "$current_hashrate > 0" | bc -l) )); then
            last_hashrate=$current_hashrate
            break
        fi
    done <<< "$last_lines"
    
    echo "$last_hashrate"
}

# Updated function to extract shares from a log line
extract_shares() {
    local line="$1"
    local shares=$(echo "$line" | grep -oP "(SHARES|SOLS): \K\d+/\d+ \(R:\d+\)")
    local accepted=$(echo "$shares" | cut -d'/' -f2 | cut -d' ' -f1)
    local rejected=$(echo "$shares" | grep -oP "R:\K\d+")
    echo "$accepted $rejected"
}

# Extract version and runner information
custom_version=v.1
gpu_runner=$(tac "$log_name" | grep -m1 -Po "(?<=Trainer: ).*?cuda.*?(?:\d+(?:\.\d+)*)(?= is (starting|running))")
cpu_runner=$(tac "$log_name" | grep -m1 -Po "(?<=Trainer: ).*?cpu.*?(?:\d+(?:\.\d+)*)(?= is (starting|running))")
epoh_runner=$(grep -Po "E:\d+" "$log_name" | tail -n1)

# Check if the log file is recent enough
diffTime=$(get_log_time_diff)
maxDelay=300

if [ "$diffTime" -lt "$maxDelay" ]; then
    ver=$(get_miner_version)
    hs_units="hs"
    
    # Detect mining algorithms
    is_xmr=$(detect_xmr_mining)
    is_qtc=$(detect_qtc_mining)

    # Set algorithm based on priority: Qubic > XMR+QTC > XMR > QTC
    # When both XMR and QTC are active, show XMR as algo but keep QTC data
    if [[ $is_xmr -eq 1 && $is_qtc -eq 1 ]]; then
        algo="XMR"
        is_xmr_qtc_combo=1  # Flag for combined mode
    elif [[ $is_xmr -eq 1 ]]; then
        algo="XMR"
        is_xmr_qtc_combo=0
    elif [[ $is_qtc -eq 1 ]]; then
        algo="QTC"
        is_xmr_qtc_combo=0
    else
        algo="qubic"
        is_xmr_qtc_combo=0
    fi

    uptime=$(get_miner_uptime)
    [[ $uptime -lt 60 ]] && head -n 150 $log_name > $log_head_name

    # Initialize arrays and counters
    declare -a hs temp fan bus_numbers
    let ac=0 rj=0

    # Handle XMR + QTC combo mode (XMR on CPU, QTC on GPU)
    if [[ $is_xmr_qtc_combo -eq 1 ]]; then
        # Get QTC data from API for GPU stats
        qtc_api_data=$(get_qtc_hashrate_data)

        if [[ "$qtc_api_data" != "{}" ]]; then
            # Extract individual GPU hashrates from QTC
            qtc_gpu_hashrates=$(extract_qtc_gpu_hashrates "$qtc_api_data")

            # Extract temperature, fan, and bus data from QTC
            qtc_temps=$(extract_qtc_temps "$qtc_api_data")
            qtc_fans=$(extract_qtc_fans "$qtc_api_data")
            qtc_busids=$(extract_qtc_busids "$qtc_api_data")

            # Count GPUs
            gpu_count=$(echo "$qtc_gpu_hashrates" | wc -l)
            [[ -z "$gpu_count" ]] && gpu_count=0

            # Process individual GPU data from QTC
            i=0
            while IFS= read -r hashrate; do
                hs[$i]=$hashrate
                [[ -z ${hs[$i]} ]] && hs[$i]=0
                i=$((i+1))
            done <<< "$qtc_gpu_hashrates"

            i=0
            while IFS= read -r temp_val; do
                temp[$i]=$temp_val
                [[ -z ${temp[$i]} ]] && temp[$i]=null
                i=$((i+1))
            done <<< "$qtc_temps"

            i=0
            while IFS= read -r fan_val; do
                fan[$i]=$fan_val
                [[ -z ${fan[$i]} ]] && fan[$i]=null
                i=$((i+1))
            done <<< "$qtc_fans"

            i=0
            while IFS= read -r busid; do
                bus_numbers[$i]=$busid
                [[ -z ${bus_numbers[$i]} ]] && bus_numbers[$i]=null
                i=$((i+1))
            done <<< "$qtc_busids"
        else
            # Fallback if QTC API is not available
            gpu_count=0
        fi

        # Get XMR CPU hashrate for total
        cpu_hs=$(extract_xmr_hashrate)
        cpu_temp=$(cpu-temp)
        cpu_count=1

        # Add CPU data to arrays (appears as additional card after GPUs)
        hs+=($cpu_hs)
        temp+=($cpu_temp)
        fan+=("")
        bus_numbers+=("null")

        # Set total hashrate to XMR (CPU) hashrate
        total_hs=$cpu_hs

        # No shares displayed for this combo mode
        ac=0
        rj=0

    # Handle QTC mining only
    elif [[ $is_qtc -eq 1 ]]; then
        # Get QTC data from API
        qtc_api_data=$(get_qtc_hashrate_data)
        
        if [[ "$qtc_api_data" != "{}" ]]; then
            # Extract total hashrate
            total_hs=$(extract_qtc_total_hashrate "$qtc_api_data")
            
            # Extract individual GPU hashrates
            qtc_gpu_hashrates=$(extract_qtc_gpu_hashrates "$qtc_api_data")
            
            # Extract temperature, fan, and bus data
            qtc_temps=$(extract_qtc_temps "$qtc_api_data")
            qtc_fans=$(extract_qtc_fans "$qtc_api_data")
            qtc_busids=$(extract_qtc_busids "$qtc_api_data")
            
            # Count GPUs
            gpu_count=$(echo "$qtc_gpu_hashrates" | wc -l)
            [[ -z "$gpu_count" ]] && gpu_count=0
            
            # Process individual GPU data
            i=0
            while IFS= read -r hashrate; do
                hs[$i]=$hashrate
                [[ -z ${hs[$i]} ]] && hs[$i]=0
                i=$((i+1))
            done <<< "$qtc_gpu_hashrates"
            
            i=0
            while IFS= read -r temp_val; do
                temp[$i]=$temp_val
                [[ -z ${temp[$i]} ]] && temp[$i]=null
                i=$((i+1))
            done <<< "$qtc_temps"
            
            i=0
            while IFS= read -r fan_val; do
                fan[$i]=$fan_val
                [[ -z ${fan[$i]} ]] && fan[$i]=null
                i=$((i+1))
            done <<< "$qtc_fans"
            
            i=0
            while IFS= read -r busid; do
                bus_numbers[$i]=$busid
                [[ -z ${bus_numbers[$i]} ]] && bus_numbers[$i]=null
                i=$((i+1))
            done <<< "$qtc_busids"
            
            # No shares displayed for QTC mining as requested
            ac=0
            rj=0
        else
            # Fallback if API is not available
            gpu_count=0
            total_hs=0
        fi
        
        cpu_count=0
        cpu_temp=null
        
    else
        # Original logic for non-QTC mining
        
        # Update GPU count detection
        gpu_count=$(grep -oP "\[GPU\] Trainer: \K\d+" "$log_name" | tail -n 1)
        [[ -z $gpu_count ]] && gpu_count=0

        # New CPU detection method
        cpu_count=$(grep -cE "\[(AVX512|AVX2|GENERIC)\]" "$log_name")
        [[ $cpu_count -gt 0 ]] && cpu_count=1 || cpu_count=0

        # Get CPU temperature if CPU is used OR if XMR mining is active
        [[ $cpu_count -eq 1 || $is_xmr -eq 1 ]] && cpu_temp=$(cpu-temp) || cpu_temp=null

        # Extract CPU hashrate based on algorithm
        if [[ $is_xmr -eq 1 ]]; then
            # For XMR, extract the XMR hashrate
            cpu_hs=$(extract_xmr_hashrate)
        else
            # For qubic, use the original method
            cpu_hs=$(get_last_valid_hashrate "(AVX512|AVX2|GENERIC)")
        fi

        # Extract individual GPU hashrates from the log format
        gpu_hashrates=$(grep "\[GPU\] Trainer:" "$log_name" | grep -v "Switching ID" | grep -v "Found a share" | grep -v "Fine-tuning completed" | tail -n $gpu_count | grep -oP "GPU #\d+: \K\d+ it/s")

        # Process GPU data
        if [[ $gpu_count -gt 0 ]]; then
            # Extract GPU shares information
            gpu_shares=$(grep "\[CUDA\]" "$log_name" | grep -E "(SHARES|SOLS):" | tail -n 1)
            if [[ -n "$gpu_shares" ]]; then
                read gpu_accepted gpu_rejected <<< $(extract_shares "$gpu_shares")
                [[ -z "$gpu_accepted" ]] && gpu_accepted=0
                [[ -z "$gpu_rejected" ]] && gpu_rejected=0
                let ac=$ac+$gpu_accepted
                let rj=$rj+$gpu_rejected
            fi

            # Extract GPU temperature, fan, and bus information
            gpu_temp=$(jq '.temp' <<< "$gpu_stats")
            gpu_fan=$(jq '.fan' <<< "$gpu_stats")
            gpu_bus=$(jq '.busids' <<< "$gpu_stats")
            if [[ $cpu_indexes_array != '[]' ]]; then
                gpu_temp=$(jq -c "del(.$cpu_indexes_array)" <<< "$gpu_temp") &&
                gpu_fan=$(jq -c "del(.$cpu_indexes_array)" <<< "$gpu_fan") &&
                gpu_bus=$(jq -c "del(.$cpu_indexes_array)" <<< "$gpu_bus")
            fi

            # Process individual GPU data
            for (( i=0; i < ${gpu_count}; i++ )); do
                hs[$i]=$(echo "$gpu_hashrates" | sed -n "$((i+1))p" | awk '{print $1}')
                [[ -z ${hs[$i]} ]] && hs[$i]=0
                temp[$i]=$(jq .[$i] <<< "$gpu_temp")
                fan[$i]=$(jq .[$i] <<< "$gpu_fan")
                busid=$(jq .[$i] <<< "$gpu_bus")
                bus_numbers[$i]=$(echo $busid | cut -d ":" -f1 | cut -c2- | awk -F: '{ printf "%d\n",("0x"$1) }')
            done
        fi

        # Process CPU stats
        if [[ $cpu_count -eq 1 ]] || [[ $is_xmr -eq 1 ]]; then
            # Extract shares information only for qubic (not for XMR)
            if [[ $is_xmr -eq 0 ]]; then
                # For qubic, use original method
                cpu_shares=$(grep -E "\[(AVX512|AVX2|GENERIC)\]" "$log_name" | grep -E "(SHARES|SOLS):" | tail -n 1)
                if [[ -n "$cpu_shares" ]]; then
                    read cpu_accepted cpu_rejected <<< $(extract_shares "$cpu_shares")
                    [[ -z "$cpu_accepted" ]] && cpu_accepted=0
                    [[ -z "$cpu_rejected" ]] && cpu_rejected=0
                    let ac=$ac+$cpu_accepted
                    let rj=$rj+$cpu_rejected
                fi
            fi
            
            # Add CPU data to arrays
            hs+=($cpu_hs)
            temp+=($cpu_temp)
            fan+=("")
            bus_numbers+=("null")
        fi

        # Adjust shares if both GPU and CPU are in use (only for non-XMR)
        if [[ $gpu_count -gt 0 && $cpu_count -eq 1 && $is_xmr -eq 0 ]]; then
            ac=$((ac / 2))
            rj=$((rj / 2))
        fi

        # Calculate total GPU hashrate
        gpu_total_hs=$(tail -n 20 "$log_name" | grep -oP '\[CUDA\].*?(\d+) avg it/s' | tail -n 1 | grep -oP '\d+(?= avg it/s)')
        gpu_total_hs=${gpu_total_hs:-0} 
        
        # Calculate total hashrate based on algorithm
        if [[ $is_xmr -eq 1 ]]; then
            # For XMR, use only the XMR hashrate
            total_hs=$cpu_hs
        else
            # For qubic, calculate GPU + CPU
            total_hs=$(echo "$gpu_total_hs + $cpu_hs" | bc)
        fi
    fi

    # Calculate total hashrate in khs
    if (( $(echo "$total_hs > 0" | bc -l) )); then
        khs=$(echo "scale=6; $total_hs / 1000" | bc)
    else
        khs=0
    fi

    # Prepare stats JSON
    stats=$(jq -nc \
                --arg khs "$khs" \
                --arg hs_units "$hs_units" \
                --argjson hs "$(printf '%s\n' "${hs[@]}" | jq -cs '.')" \
                --argjson temp "$(printf '%s\n' "${temp[@]}" | jq -cs '.')" \
                --argjson fan "$(printf '%s\n' "${fan[@]}" | jq -cs '.')" \
                --arg uptime "$uptime" \
                --arg ver "$ver" \
                --arg ac "$ac" --arg rj "$rj" \
                --arg algo "$algo" \
                --argjson bus_numbers "$(printf '%s\n' "${bus_numbers[@]}" | jq -cs '.')" \
                '{$hs, $hs_units, $temp, $fan, $uptime, $ver, ar: [$ac, $rj], $algo, $bus_numbers}')
else
    stats=""
    khs=0
fi

# Output results
echo $khs
echo $stats