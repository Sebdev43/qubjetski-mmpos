#!/bin/bash

process_user_config() {
    while IFS= read -r line; do
        [[ -z $line ]] && continue

        # Check if the line starts with nvtool and execute it using eval
        if [[ ${line:0:7} = "nvtool " ]]; then
            eval "$line"
        else
            # Remove spaces only from the beginning of the line
            line=$(echo "$line" | sed 's/^[[:space:]]*//')
            
            # Extract parameter and value using sed instead of awk for JSON
            param=$(echo "$line" | sed -E 's/^"?([^"]*)"?\s*:.*/\1/')
            value=$(echo "$line" | sed -E 's/^"?[^"]*"?\s*:\s*//')

            # Convert parameter to lowercase for cpuOnly check
            param_low=$(echo "$param" | tr '[:upper:]' '[:lower:]')

            # Check for CPU only mode (case-insensitive)
            if [[ "$param_low" == "cpuonly" && ("$value" == "true" || "$value" == "\"true\"" || "$value" == "yes" || "$value" == "\"yes\"") ]]; then
                CPU_ONLY=true
                continue
            fi

            # Store amountOfThreads parameter for later processing
            if [[ "$param" == "amountOfThreads" ]]; then
                AMOUNT_OF_THREADS=$value
                continue
            fi

            # Store trainer configuration if present
            if [[ "$param" == "trainer" ]]; then
                TRAINER_CONFIG=$line
                continue
            fi

            # idleSettings Handlers
            if [[ "$param" == "idleSettings" ]]; then
                # Parse the idleSettings JSON object
                # Remove outer quotes if present
                idle_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                
                # Extract individual idle settings
                if echo "$idle_value" | grep -q "preCommand"; then
                    pre_command=$(echo "$idle_value" | sed -E 's/.*"preCommand":\s*"([^"]*)".*|.*/\1/')
                    if [[ ! -z "$pre_command" ]]; then
                        Settings=$(jq --arg cmd "$pre_command" '.idling.preCommand = $cmd' <<< "$Settings")
                    fi
                fi
                
                if echo "$idle_value" | grep -q "preCommandArguments"; then
                    pre_args=$(echo "$idle_value" | sed -E 's/.*"preCommandArguments":\s*"([^"]*)".*|.*/\1/')
                    if [[ ! -z "$pre_args" ]]; then
                        Settings=$(jq --arg args "$pre_args" '.idling.preCommandArguments = $args' <<< "$Settings")
                    fi
                fi
                
                if echo "$idle_value" | grep -q "postCommand"; then
                    post_command=$(echo "$idle_value" | sed -E 's/.*"postCommand":\s*"([^"]*)".*|.*/\1/')
                    if [[ ! -z "$post_command" ]]; then
                        Settings=$(jq --arg cmd "$post_command" '.idling.postCommand = $cmd' <<< "$Settings")
                    fi
                fi
                
                if echo "$idle_value" | grep -q "postCommandArguments"; then
                    post_args=$(echo "$idle_value" | sed -E 's/.*"postCommandArguments":\s*"([^"]*)".*|.*/\1/')
                    if [[ ! -z "$post_args" ]]; then
                        Settings=$(jq --arg args "$post_args" '.idling.postCommandArguments = $args' <<< "$Settings")
                    fi
                fi

                # Handle command override (use negative lookbehind to avoid matching preCommand/postCommand)
                if echo "$idle_value" | grep -qE '(^|[,{])\s*"command"\s*:'; then
                    idle_command=$(echo "$idle_value" | sed -E 's/.*[,{]\s*"command":\s*"([^"]*)".*|.*^"command":\s*"([^"]*)".*|.*/\1\2/')
                    if [[ ! -z "$idle_command" ]]; then
                        Settings=$(jq --arg cmd "$idle_command" '.idling.command = $cmd' <<< "$Settings")
                    fi
                fi

                # Handle arguments override (use negative lookbehind to avoid matching preCommandArguments/postCommandArguments)
                if echo "$idle_value" | grep -qE '(^|[,{])\s*"arguments"\s*:'; then
                    idle_arguments=$(echo "$idle_value" | sed -E 's/.*[,{]\s*"arguments":\s*"([^"]*)".*|.*^"arguments":\s*"([^"]*)".*|.*/\1\2/')
                    if [[ ! -z "$idle_arguments" ]]; then
                        Settings=$(jq --arg args "$idle_arguments" '.idling.arguments = $args' <<< "$Settings")
                    fi
                fi
                continue
            fi

            # Alternative way to handle individual idle settings parameters
            if [[ "$param" == "idleCommand" ]]; then
                clean_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                Settings=$(jq --arg cmd "$clean_value" '.idling.command = $cmd' <<< "$Settings")
                continue
            fi

            if [[ "$param" == "idleArguments" ]]; then
                clean_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                Settings=$(jq --arg args "$clean_value" '.idling.arguments = $args' <<< "$Settings")
                continue
            fi

            if [[ "$param" == "idlePreCommand" ]]; then
                clean_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                Settings=$(jq --arg cmd "$clean_value" '.idling.preCommand = $cmd' <<< "$Settings")
                continue
            fi

            if [[ "$param" == "idlePreCommandArguments" ]]; then
                clean_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                Settings=$(jq --arg args "$clean_value" '.idling.preCommandArguments = $args' <<< "$Settings")
                continue
            fi

            if [[ "$param" == "idlePostCommand" ]]; then
                clean_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                Settings=$(jq --arg cmd "$clean_value" '.idling.postCommand = $cmd' <<< "$Settings")
                continue
            fi

            if [[ "$param" == "idlePostCommandArguments" ]]; then
                clean_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                Settings=$(jq --arg args "$clean_value" '.idling.postCommandArguments = $args' <<< "$Settings")
                continue
            fi

            # XMR Settings Handlers
            if [[ "$param" == "xmrMining" ]]; then
                if [[ "$value" == "true" || "$value" == "\"true\"" ]]; then
                    Settings=$(jq '.xmrSettings.disable = false' <<< "$Settings")
                elif [[ "$value" == "false" || "$value" == "\"false\"" ]]; then
                    Settings=$(jq '.xmrSettings.disable = true' <<< "$Settings")
                fi
                continue
            fi

            if [[ "$param" == "xmrGpu" ]]; then
                if [[ "$value" == "true" || "$value" == "\"true\"" ]]; then
                    Settings=$(jq '.xmrSettings.enableGpu = true' <<< "$Settings")
                elif [[ "$value" == "false" || "$value" == "\"false\"" ]]; then
                    Settings=$(jq '.xmrSettings.enableGpu = false' <<< "$Settings")
                fi
                continue
            fi

            if [[ "$param" == "xmrPool" ]]; then
                # Remove quotes if present in the value
                clean_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                Settings=$(jq --arg pool "$clean_value" '.xmrSettings.poolAddress = $pool' <<< "$Settings")
                continue
            fi

            if [[ "$param" == "xmrCustom" ]]; then
                # Remove quotes if present in the value
                clean_value=$(echo "$value" | sed -E 's/^"(.*)"$/\1/')
                Settings=$(jq --arg custom "$clean_value" '.xmrSettings.customParameters = $custom' <<< "$Settings")
                continue
            fi

            # Convert parameter to uppercase for other processing
            param_high=$(echo "$param" | tr '[:lower:]' '[:upper:]')

            # Perform replacements in the parameter
            modified_param=$(echo "$param_high" | sed '
                s/QUBICADDRESS/qubicAddress/g;
                s/CPUTHREADS/cpuThreads/g;
                s/ACCESSTOKEN/accessToken/g;
                s/ALLOWHWINFOCOLLECT/allowHwInfoCollect/g;
                s/HUGEPAGES/hugePages/g;
                s/ALIAS/alias/g;
                s/OVERWRITES/overwrites/g;
                s/PPS=/\"pps\": /g;
                s/USELIVECONNECTION/useLiveConnection/g;
                s/TRAINER/trainer/g;
            ')

            # Check if modifications were made, if not, use the original parameter
            [[ "$param" != "$modified_param" ]] && param=$modified_param

            # General processing for other parameters
            if [[ ! -z "$value" ]]; then
                if [[ "$param" == "overwrites" ]]; then
                    Settings=$(jq -s '.[0] * .[1]' <<< "$Settings {$line}")
                elif [[ "$param" == "pps" || "$param" == "useLiveConnection" ]]; then
                    if [[ "$value" == "true" || "$value" == "false" ]]; then
                        Settings=$(jq --argjson value "$value" '.[$param] = $value' <<< "$Settings")
                    else
                        echo "Invalid value for $param: $value. It must be 'true' or 'false'. Skipping this entry."
                    fi
                else
                    if [[ "$param" == "trainer.cpuThreads" ]]; then
                        Settings=$(jq --arg value "$value" '.trainer.cpuThreads = ($value | tonumber)' <<< "$Settings")
                    elif [[ "$param" == "trainer.gpu" ]]; then
                        Settings=$(jq --argjson value "$value" '.trainer.gpu = $value' <<< "$Settings")
                    elif [[ "$value" == "null" ]]; then
                        Settings=$(jq --arg param "$param" '.[$param] = null' <<< "$Settings")
                    elif [[ "$value" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
                        Settings=$(jq --arg param "$param" --argjson value "$value" '.[$param] = ($value | tonumber)' <<< "$Settings")
                    else
                        Settings=$(jq --arg param "$param" --arg value "$value" '.[$param] = $value' <<< "$Settings")
                    fi
                fi
            fi
        fi
    done <<< "$CUSTOM_USER_CONFIG"
}

# Function to backup stats files
backup_stats_files() {
    local miner_dir="/hive/miners/custom/$CUSTOM_NAME"
    local backup_dir="/tmp/miner_stats_backup"
    
    # Create backup directory
    mkdir -p "$backup_dir"
    
    # Find and copy all stats.*.lock files
    if ls "$miner_dir"/stats.*.lock 2>/dev/null 1>&2; then
        cp -p "$miner_dir"/stats.*.lock "$backup_dir/" 2>/dev/null
    else
        echo ""
    fi
}

# Function to restore stats files
restore_stats_files() {
    local miner_dir="/hive/miners/custom/$CUSTOM_NAME"
    local backup_dir="/tmp/miner_stats_backup"
    
    # Check if backup directory exists and contains files
    if [ -d "$backup_dir" ] && ls "$backup_dir"/stats.*.lock 2>/dev/null 1>&2; then
        echo "Restoring stats files..."
        # Wait a bit for the miner to be extracted
        sleep 5
        # Restore the files
        cp -p "$backup_dir"/stats.*.lock "$miner_dir/" 2>/dev/null
        echo "Stats files restored!"
        # Clean up backup directory
        rm -rf "$backup_dir"
    else
        echo "Stats loaded..."
    fi
}

# Main script logic

# Always check for updates first
LOCAL_FILE="/hive/miners/custom/downloads/qubjetski.PPLNS-latest.tar.gz"
REMOTE_FILE_URL="https://github.com/jtskxx/Jetski-Qubic-Pool/releases/download/latest/qubjetski.PPLNS-latest.tar.gz"
REMOTE_HASH_URL="https://github.com/jtskxx/Jetski-Qubic-Pool/releases/download/latest/qubjetski.PPLNS-latest.hash"

# Check if we need to restore stats files from a previous update
restore_stats_files

# Check the availability of the remote hash
if curl --output /dev/null --silent --head --fail "$REMOTE_HASH_URL"; then
    # Download the remote hash
    REMOTE_HASH=$(curl -s -L "$REMOTE_HASH_URL")

    # Calculate the SHA256 hash of the local file
    LOCAL_HASH=$(sha256sum "$LOCAL_FILE" | awk '{print $1}')

    # Compare the hashes
    if [ "$LOCAL_HASH" != "$REMOTE_HASH" ]; then
        echo "F*ck Hashes of local and remote ($REMOTE_FILE_URL) miners are different. Let's download the update :D."
        
        # Backup stats files before update
        backup_stats_files
        
        # Remove old local miner and restart the miner
        rm "$LOCAL_FILE"
        echo "Miner restarting in 10 sec..."
        
        # Create a marker file to indicate stats need to be restored after restart
        touch /tmp/miner_stats_restore_pending
        
        screen -d -m miner restart
    fi
fi

# Processing global settings
GlobalSettings=$(jq -r '.ClientSettings' "/hive/miners/custom/$CUSTOM_NAME/appsettings_global.json" | envsubst)

# Initialize Settings
Settings="$GlobalSettings"

# Delete old settings
eval "rm -rf /hive/miners/custom/$CUSTOM_NAME/appsettings.json"

# Processing the template (alias)
if [[ ! -z $CUSTOM_TEMPLATE ]]; then
    # Split the template at the '-' character
    POOL_PART=$(echo "$CUSTOM_TEMPLATE" | cut -d'-' -f1)
    ALIAS_PART=$(echo "$CUSTOM_TEMPLATE" | cut -d'-' -f2-)
    
    # Update poolAddress with the pool part
    Settings=$(jq --arg pool "wss://pplns.jtskxpool.ai/ws/$POOL_PART" '.poolAddress = $pool' <<< "$Settings")
    
    # Update idling arguments to replace WALLET with POOL_PART
    Settings=$(jq --arg wallet "$POOL_PART" '.idling.arguments |= gsub("WALLET"; $wallet)' <<< "$Settings")
    
    # Update alias with the remaining part (only if it exists)
    if [[ ! -z "$ALIAS_PART" ]]; then
        Settings=$(jq --arg alias "$ALIAS_PART" '.alias = $alias' <<< "$Settings")
    fi
fi

# Processing user configuration
[[ ! -z $CUSTOM_USER_CONFIG ]] && process_user_config

# Check and modify Settings for hugePages parameter
if [[ $(jq '.hugePages' <<< "$Settings") != null ]]; then
    hugePages=$(jq -r '.hugePages' <<< "$Settings")
    if [[ ! -z $hugePages && $hugePages -gt 0 ]]; then
        eval "sysctl -w vm.nr_hugepages=$hugePages"
    fi
fi

# Store existing trainer settings that we want to preserve
if [[ ! -z "$TRAINER_CONFIG" ]]; then
    EXISTING_TRAINER=$(jq -r '.trainer' <<< "$Settings")
fi

# Configure trainer settings based on user input
Settings=$(jq 'del(.cpuOnly)' <<< "$Settings")

# Logic for CPU/GPU configuration while preserving existing trainer settings
if [[ "$CPU_ONLY" == "true" ]]; then
    if [[ ! -z "$AMOUNT_OF_THREADS" ]]; then
        # CPU only mode with specified threads
        Settings=$(jq --arg threads "$AMOUNT_OF_THREADS" '
            .trainer.cpu = true | 
            .trainer.gpu = false |
            .trainer.cpuThreads = ($threads | tonumber)
        ' <<< "$Settings")
    else
        # CPU only mode without threads specified
        Settings=$(jq '.trainer.cpu = true | .trainer.gpu = false' <<< "$Settings")
    fi
elif [[ ! -z "$AMOUNT_OF_THREADS" ]]; then
    # Both CPU and GPU, with specified threads
    Settings=$(jq --arg threads "$AMOUNT_OF_THREADS" '
        .trainer.cpu = true |
        .trainer.gpu = true |
        .trainer.cpuThreads = ($threads | tonumber)
    ' <<< "$Settings")
else
    # GPU only mode (default)
    Settings=$(jq '.trainer.cpu = false | .trainer.gpu = true' <<< "$Settings")
fi

# Apply trainer configuration if it exists
if [[ ! -z "$TRAINER_CONFIG" ]]; then
    Settings=$(jq -s '.[0] * .[1]' <<< "$Settings {$TRAINER_CONFIG}")
fi

# Remove idling settings when in CPU only mode
if [[ "$CPU_ONLY" == "true" ]]; then
    Settings=$(jq 'del(.idling)' <<< "$Settings")
fi

# Create the final settings file
echo "{\"ClientSettings\":$Settings}" | jq . > "/hive/miners/custom/$CUSTOM_NAME/appsettings.json"

echo "Settings created successfully."