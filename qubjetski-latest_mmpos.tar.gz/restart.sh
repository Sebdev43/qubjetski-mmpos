#!/bin/bash

# Define lock file
LOCKFILE="/var/lock/miner_restart.lock"

# Define file paths and URLs (from your config)
LOCAL_FILE="/hive/miners/custom/downloads/qubjetski.PPLNS-latest.tar.gz"
REMOTE_HASH_URL="https://github.com/jtskxx/Jetski-Qubic-Pool/releases/download/latest/qubjetski.PPLNS-latest.hash"

# Try to acquire exclusive lock, exit if another instance is running
(
    flock -n 200 || { echo "Another instance is already running"; exit 1; }
    
    # Main monitoring loop
    while true; do
        # Sleep for 2 hours before check
        echo "[$(date)] Sleeping for 7200 seconds (2 hours)..."
        sleep 3600
        
        echo "[$(date)] Checking for updates..."
        
        # Check if the remote hash URL is available
        if curl --output /dev/null --silent --head --fail "$REMOTE_HASH_URL"; then
            # Download the remote hash
            REMOTE_HASH=$(curl -s -L "$REMOTE_HASH_URL")
            
            # Check if local file exists
            if [ -f "$LOCAL_FILE" ]; then
                # Calculate the SHA256 hash of the local file
                LOCAL_HASH=$(sha256sum "$LOCAL_FILE" | awk '{print $1}')
                
                if [ "$LOCAL_HASH" != "$REMOTE_HASH" ]; then
                    echo "[$(date)] Hash mismatch detected! Local: $LOCAL_HASH | Remote: $REMOTE_HASH"
                    echo "[$(date)] Triggering miner restart..."
                    
                    miner restart
                else
                    echo "[$(date)] Hash match - no update needed"
                fi
            else
                echo "[$(date)] Local file not found: $LOCAL_FILE"
            fi
        else
            echo "[$(date)] Unable to fetch remote hash from: $REMOTE_HASH_URL"
        fi
    done
    
) 200>$LOCKFILE